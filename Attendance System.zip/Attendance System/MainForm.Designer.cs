﻿namespace Attendance_System
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            dateTimePicker1 = new DateTimePicker();
            label1 = new Label();
            panel2 = new Panel();
            panel6 = new Panel();
            panel7 = new Panel();
            button6 = new Button();
            button5 = new Button();
            pictureBox1 = new PictureBox();
            label5 = new Label();
            logoutbtn = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            label4 = new Label();
            label3 = new Label();
            panel3 = new Panel();
            panel4 = new Panel();
            button8 = new Button();
            button7 = new Button();
            panel5 = new Panel();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel3.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.WhiteSmoke;
            panel1.Controls.Add(dateTimePicker1);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1165, 35);
            panel1.TabIndex = 0;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(3, 5);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(250, 27);
            dateTimePicker1.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(1138, 6);
            label1.Name = "label1";
            label1.Size = new Size(24, 24);
            label1.TabIndex = 0;
            label1.Text = "X";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(128, 196, 233);
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(panel6);
            panel2.Controls.Add(button6);
            panel2.Controls.Add(button5);
            panel2.Controls.Add(pictureBox1);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(logoutbtn);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(button2);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label3);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(0, 35);
            panel2.Name = "panel2";
            panel2.Size = new Size(253, 687);
            panel2.TabIndex = 3;
            // 
            // panel6
            // 
            panel6.Controls.Add(panel7);
            panel6.Location = new Point(-1, 191);
            panel6.Name = "panel6";
            panel6.Size = new Size(8, 495);
            panel6.TabIndex = 11;
            // 
            // panel7
            // 
            panel7.BackColor = Color.White;
            panel7.Location = new Point(0, 0);
            panel7.Name = "panel7";
            panel7.Size = new Size(8, 40);
            panel7.TabIndex = 0;
            // 
            // button6
            // 
            button6.Cursor = Cursors.Hand;
            button6.FlatAppearance.MouseDownBackColor = Color.Orchid;
            button6.FlatAppearance.MouseOverBackColor = Color.Orchid;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button6.ForeColor = Color.Black;
            button6.Image = Properties.Resources.icons8_setting_32;
            button6.ImageAlign = ContentAlignment.MiddleLeft;
            button6.Location = new Point(26, 449);
            button6.Name = "button6";
            button6.Size = new Size(222, 45);
            button6.TabIndex = 10;
            button6.Text = "Register";
            button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Cursor = Cursors.Hand;
            button5.FlatAppearance.MouseDownBackColor = Color.Orchid;
            button5.FlatAppearance.MouseOverBackColor = Color.Orchid;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button5.ForeColor = Color.Black;
            button5.Image = Properties.Resources.icons8_paper_32;
            button5.ImageAlign = ContentAlignment.MiddleLeft;
            button5.Location = new Point(26, 398);
            button5.Name = "button5";
            button5.Size = new Size(222, 45);
            button5.TabIndex = 9;
            button5.Text = "Report";
            button5.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.icons8_admin_100;
            pictureBox1.Location = new Point(73, 16);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(100, 100);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Tahoma", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(64, 641);
            label5.Name = "label5";
            label5.Size = new Size(68, 21);
            label5.TabIndex = 3;
            label5.Text = "Log Out";
            // 
            // logoutbtn
            // 
            logoutbtn.Cursor = Cursors.Hand;
            logoutbtn.FlatAppearance.MouseDownBackColor = Color.Orchid;
            logoutbtn.FlatAppearance.MouseOverBackColor = Color.Orchid;
            logoutbtn.FlatStyle = FlatStyle.Flat;
            logoutbtn.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            logoutbtn.ForeColor = Color.Black;
            logoutbtn.Image = Properties.Resources.icons8_log_out_32;
            logoutbtn.Location = new Point(13, 629);
            logoutbtn.Name = "logoutbtn";
            logoutbtn.Size = new Size(45, 45);
            logoutbtn.TabIndex = 8;
            logoutbtn.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Cursor = Cursors.Hand;
            button4.FlatAppearance.MouseDownBackColor = Color.Orchid;
            button4.FlatAppearance.MouseOverBackColor = Color.Orchid;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.ForeColor = Color.Black;
            button4.Image = Properties.Resources.icons8_student_registration_32;
            button4.ImageAlign = ContentAlignment.MiddleLeft;
            button4.Location = new Point(26, 347);
            button4.Name = "button4";
            button4.Size = new Size(222, 45);
            button4.TabIndex = 7;
            button4.Text = "   Add Student";
            button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Cursor = Cursors.Hand;
            button3.FlatAppearance.MouseDownBackColor = Color.Orchid;
            button3.FlatAppearance.MouseOverBackColor = Color.Orchid;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = Color.Black;
            button3.Image = Properties.Resources.icons8_teacher_32;
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.Location = new Point(26, 296);
            button3.Name = "button3";
            button3.Size = new Size(222, 45);
            button3.TabIndex = 6;
            button3.Text = "  Add Class";
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Cursor = Cursors.Hand;
            button2.FlatAppearance.MouseDownBackColor = Color.Orchid;
            button2.FlatAppearance.MouseOverBackColor = Color.Orchid;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Black;
            button2.Image = Properties.Resources.icons8_list_32;
            button2.ImageAlign = ContentAlignment.MiddleLeft;
            button2.Location = new Point(26, 245);
            button2.Name = "button2";
            button2.Size = new Size(222, 45);
            button2.TabIndex = 5;
            button2.Text = "  Attendance";
            button2.TextImageRelation = TextImageRelation.ImageBeforeText;
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.MouseDownBackColor = Color.Orchid;
            button1.FlatAppearance.MouseOverBackColor = Color.Orchid;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Black;
            button1.Image = Properties.Resources.icons8_computer_32;
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(26, 194);
            button1.Name = "button1";
            button1.Size = new Size(222, 45);
            button1.TabIndex = 4;
            button1.Text = "  Dashboard";
            button1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(39, 134);
            label4.Name = "label4";
            label4.Size = new Size(165, 22);
            label4.TabIndex = 3;
            label4.Text = "Welcome, Admin";
            // 
            // label3
            // 
            label3.Location = new Point(73, 16);
            label3.Name = "label3";
            label3.Size = new Size(100, 100);
            label3.TabIndex = 3;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(128, 196, 233);
            panel3.Controls.Add(panel4);
            panel3.Controls.Add(pictureBox3);
            panel3.Controls.Add(pictureBox2);
            panel3.Location = new Point(252, 35);
            panel3.Name = "panel3";
            panel3.Size = new Size(913, 170);
            panel3.TabIndex = 4;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(128, 196, 233);
            panel4.Controls.Add(button8);
            panel4.Controls.Add(button7);
            panel4.Controls.Add(panel5);
            panel4.Location = new Point(686, 66);
            panel4.Name = "panel4";
            panel4.Size = new Size(218, 101);
            panel4.TabIndex = 5;
            // 
            // button8
            // 
            button8.BackColor = Color.White;
            button8.Cursor = Cursors.Hand;
            button8.Dock = DockStyle.Bottom;
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Font = new Font("Century", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button8.ForeColor = Color.FromArgb(128, 196, 233);
            button8.Image = Properties.Resources.icons8_log_out_201;
            button8.Location = new Point(0, 56);
            button8.Name = "button8";
            button8.Size = new Size(218, 45);
            button8.TabIndex = 2;
            button8.Text = "  Log Out";
            button8.TextImageRelation = TextImageRelation.ImageBeforeText;
            button8.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            button7.BackColor = Color.White;
            button7.Cursor = Cursors.Hand;
            button7.Dock = DockStyle.Top;
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Century", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button7.ForeColor = Color.FromArgb(128, 196, 233);
            button7.Image = Properties.Resources.icons8_macos_minimize_20;
            button7.Location = new Point(0, 10);
            button7.Name = "button7";
            button7.Size = new Size(218, 44);
            button7.TabIndex = 1;
            button7.Text = "  Minimize";
            button7.TextImageRelation = TextImageRelation.ImageBeforeText;
            button7.UseVisualStyleBackColor = false;
            // 
            // panel5
            // 
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(218, 10);
            panel5.TabIndex = 0;
            // 
            // pictureBox3
            // 
            pictureBox3.Cursor = Cursors.Hand;
            pictureBox3.Image = Properties.Resources.icons8_arrow_down_27;
            pictureBox3.Location = new Point(762, 42);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(27, 26);
            pictureBox3.TabIndex = 1;
            pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.icons8_student_activity_70;
            pictureBox2.Location = new Point(686, 8);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(70, 60);
            pictureBox2.TabIndex = 0;
            pictureBox2.TabStop = false;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1165, 722);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "MainForm";
            Text = "MainForm";
            Load += MainForm_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel3.ResumeLayout(false);
            panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Button button6;
        private Button button5;
        private PictureBox pictureBox1;
        private Label label5;
        private Button logoutbtn;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private Label label4;
        private Label label3;
        private Label label1;
        private DateTimePicker dateTimePicker1;
        private Panel panel3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private Panel panel4;
        private Panel panel5;
        private Button button7;
        private Button button8;
        private Panel panel6;
        private Panel panel7;
    }
}