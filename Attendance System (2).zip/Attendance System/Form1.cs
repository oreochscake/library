namespace Attendance_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            panel2.Width += 6;

            if (panel2.Width >= 675)
            {
                timer1.Stop();

                LogInForm form1 = new LogInForm();
                form1.Show();
                this.Hide();
            }
        }
    }
}
