﻿namespace Attendance_System
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabPageAddStudent = new TabPage();
            radioButtonMale1 = new RadioButton();
            radioButtonFemale1 = new RadioButton();
            comboBoxclass = new ComboBox();
            buttonAdd = new Button();
            panel3 = new Panel();
            label5 = new Label();
            textBoxMale = new TextBox();
            panel2 = new Panel();
            label4 = new Label();
            textBoxRegNo = new TextBox();
            panel1 = new Panel();
            label3 = new Label();
            textBoxName = new TextBox();
            label2 = new Label();
            label1 = new Label();
            tabPageSearchstudent = new TabPage();
            comboBox1 = new ComboBox();
            panel4 = new Panel();
            label9 = new Label();
            labelCountStudent = new Label();
            label8 = new Label();
            dataGridViewStudent = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            pictureBox1 = new PictureBox();
            panel5 = new Panel();
            textBoxSearch = new TextBox();
            label6 = new Label();
            label7 = new Label();
            tabPageUpClass = new TabPage();
            radioButtonMale2 = new RadioButton();
            radioButtonFemale2 = new RadioButton();
            comboBox2 = new ComboBox();
            panel6 = new Panel();
            labelGender1 = new Label();
            textBox1 = new TextBox();
            panel7 = new Panel();
            labelClass1 = new Label();
            textBox2 = new TextBox();
            panel8 = new Panel();
            labelRegNo1 = new Label();
            textBox3 = new TextBox();
            labelName1 = new Label();
            buttonDelete = new Button();
            buttonUpdate = new Button();
            label14 = new Label();
            tabControl1.SuspendLayout();
            tabPageAddStudent.SuspendLayout();
            tabPageSearchstudent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewStudent).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tabPageUpClass.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Alignment = TabAlignment.Bottom;
            tabControl1.Controls.Add(tabPageAddStudent);
            tabControl1.Controls.Add(tabPageSearchstudent);
            tabControl1.Controls.Add(tabPageUpClass);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Font = new Font("Century", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1165, 722);
            tabControl1.TabIndex = 1;
            // 
            // tabPageAddStudent
            // 
            tabPageAddStudent.Controls.Add(radioButtonMale1);
            tabPageAddStudent.Controls.Add(radioButtonFemale1);
            tabPageAddStudent.Controls.Add(comboBoxclass);
            tabPageAddStudent.Controls.Add(buttonAdd);
            tabPageAddStudent.Controls.Add(panel3);
            tabPageAddStudent.Controls.Add(label5);
            tabPageAddStudent.Controls.Add(textBoxMale);
            tabPageAddStudent.Controls.Add(panel2);
            tabPageAddStudent.Controls.Add(label4);
            tabPageAddStudent.Controls.Add(textBoxRegNo);
            tabPageAddStudent.Controls.Add(panel1);
            tabPageAddStudent.Controls.Add(label3);
            tabPageAddStudent.Controls.Add(textBoxName);
            tabPageAddStudent.Controls.Add(label2);
            tabPageAddStudent.Controls.Add(label1);
            tabPageAddStudent.Location = new Point(4, 4);
            tabPageAddStudent.Name = "tabPageAddStudent";
            tabPageAddStudent.Padding = new Padding(3);
            tabPageAddStudent.Size = new Size(1157, 691);
            tabPageAddStudent.TabIndex = 0;
            tabPageAddStudent.Text = "Add Student";
            tabPageAddStudent.UseVisualStyleBackColor = true;
            // 
            // radioButtonMale1
            // 
            radioButtonMale1.AutoSize = true;
            radioButtonMale1.Font = new Font("Century", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            radioButtonMale1.Location = new Point(789, 319);
            radioButtonMale1.Name = "radioButtonMale1";
            radioButtonMale1.Size = new Size(77, 26);
            radioButtonMale1.TabIndex = 17;
            radioButtonMale1.TabStop = true;
            radioButtonMale1.Text = "Male";
            radioButtonMale1.UseVisualStyleBackColor = true;
            // 
            // radioButtonFemale1
            // 
            radioButtonFemale1.AutoSize = true;
            radioButtonFemale1.Font = new Font("Century", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            radioButtonFemale1.Location = new Point(789, 370);
            radioButtonFemale1.Name = "radioButtonFemale1";
            radioButtonFemale1.Size = new Size(99, 26);
            radioButtonFemale1.TabIndex = 16;
            radioButtonFemale1.TabStop = true;
            radioButtonFemale1.Text = "Female";
            radioButtonFemale1.UseVisualStyleBackColor = true;
            // 
            // comboBoxclass
            // 
            comboBoxclass.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxclass.FlatStyle = FlatStyle.Flat;
            comboBoxclass.FormattingEnabled = true;
            comboBoxclass.Items.AddRange(new object[] { "-- SELECT --" });
            comboBoxclass.Location = new Point(124, 310);
            comboBoxclass.Name = "comboBoxclass";
            comboBoxclass.Size = new Size(270, 26);
            comboBoxclass.TabIndex = 15;
            // 
            // buttonAdd
            // 
            buttonAdd.Anchor = AnchorStyles.None;
            buttonAdd.BackColor = Color.FromArgb(128, 196, 233);
            buttonAdd.Cursor = Cursors.Hand;
            buttonAdd.FlatAppearance.BorderSize = 0;
            buttonAdd.FlatStyle = FlatStyle.Flat;
            buttonAdd.Font = new Font("Century", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonAdd.Location = new Point(124, 419);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(114, 37);
            buttonAdd.TabIndex = 14;
            buttonAdd.Text = "Add";
            buttonAdd.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            panel3.Anchor = AnchorStyles.None;
            panel3.BackColor = Color.LightGray;
            panel3.Location = new Point(124, 336);
            panel3.Name = "panel3";
            panel3.Size = new Size(270, 2);
            panel3.TabIndex = 10;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(680, 286);
            label5.Name = "label5";
            label5.Size = new Size(91, 23);
            label5.TabIndex = 11;
            label5.Text = "Gender:";
            // 
            // textBoxMale
            // 
            textBoxMale.Anchor = AnchorStyles.None;
            textBoxMale.BorderStyle = BorderStyle.None;
            textBoxMale.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBoxMale.Location = new Point(124, 312);
            textBoxMale.Name = "textBoxMale";
            textBoxMale.Size = new Size(270, 21);
            textBoxMale.TabIndex = 9;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.None;
            panel2.BackColor = Color.LightGray;
            panel2.Location = new Point(684, 188);
            panel2.Name = "panel2";
            panel2.Size = new Size(270, 2);
            panel2.TabIndex = 7;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(119, 274);
            label4.Name = "label4";
            label4.Size = new Size(71, 23);
            label4.TabIndex = 8;
            label4.Text = "Class:";
            // 
            // textBoxRegNo
            // 
            textBoxRegNo.Anchor = AnchorStyles.None;
            textBoxRegNo.BorderStyle = BorderStyle.None;
            textBoxRegNo.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBoxRegNo.Location = new Point(684, 164);
            textBoxRegNo.Name = "textBoxRegNo";
            textBoxRegNo.Size = new Size(270, 21);
            textBoxRegNo.TabIndex = 6;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.None;
            panel1.BackColor = Color.LightGray;
            panel1.Location = new Point(124, 188);
            panel1.Name = "panel1";
            panel1.Size = new Size(270, 2);
            panel1.TabIndex = 4;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(680, 126);
            label3.Name = "label3";
            label3.Size = new Size(90, 23);
            label3.TabIndex = 5;
            label3.Text = "Reg No:";
            // 
            // textBoxName
            // 
            textBoxName.Anchor = AnchorStyles.None;
            textBoxName.BorderStyle = BorderStyle.None;
            textBoxName.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBoxName.Location = new Point(124, 164);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(270, 21);
            textBoxName.TabIndex = 3;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(120, 126);
            label2.Name = "label2";
            label2.Size = new Size(76, 23);
            label2.TabIndex = 2;
            label2.Text = "Name:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(87, 143, 202);
            label1.Location = new Point(24, 23);
            label1.Name = "label1";
            label1.Size = new Size(128, 28);
            label1.TabIndex = 1;
            label1.Text = "Add User:";
            // 
            // tabPageSearchstudent
            // 
            tabPageSearchstudent.Controls.Add(comboBox1);
            tabPageSearchstudent.Controls.Add(panel4);
            tabPageSearchstudent.Controls.Add(label9);
            tabPageSearchstudent.Controls.Add(labelCountStudent);
            tabPageSearchstudent.Controls.Add(label8);
            tabPageSearchstudent.Controls.Add(dataGridViewStudent);
            tabPageSearchstudent.Controls.Add(pictureBox1);
            tabPageSearchstudent.Controls.Add(panel5);
            tabPageSearchstudent.Controls.Add(textBoxSearch);
            tabPageSearchstudent.Controls.Add(label6);
            tabPageSearchstudent.Controls.Add(label7);
            tabPageSearchstudent.Location = new Point(4, 4);
            tabPageSearchstudent.Name = "tabPageSearchstudent";
            tabPageSearchstudent.Padding = new Padding(3);
            tabPageSearchstudent.Size = new Size(1157, 691);
            tabPageSearchstudent.TabIndex = 1;
            tabPageSearchstudent.Text = "Search Student";
            tabPageSearchstudent.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.FlatStyle = FlatStyle.Flat;
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "-- SELECT --", "Name", "Reg No.", "Class" });
            comboBox1.Location = new Point(675, 126);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 26);
            comboBox1.TabIndex = 19;
            // 
            // panel4
            // 
            panel4.Anchor = AnchorStyles.None;
            panel4.BackColor = Color.LightGray;
            panel4.Location = new Point(675, 156);
            panel4.Name = "panel4";
            panel4.Size = new Size(151, 2);
            panel4.TabIndex = 18;
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.None;
            label9.AutoSize = true;
            label9.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(669, 94);
            label9.Name = "label9";
            label9.Size = new Size(118, 23);
            label9.TabIndex = 16;
            label9.Text = "Search by:";
            // 
            // labelCountStudent
            // 
            labelCountStudent.AutoSize = true;
            labelCountStudent.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelCountStudent.Location = new Point(980, 642);
            labelCountStudent.Name = "labelCountStudent";
            labelCountStudent.Size = new Size(34, 23);
            labelCountStudent.TabIndex = 12;
            labelCountStudent.Text = "{?}";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(822, 642);
            label8.Name = "label8";
            label8.Size = new Size(152, 23);
            label8.TabIndex = 11;
            label8.Text = "Total Classes:";
            // 
            // dataGridViewStudent
            // 
            dataGridViewStudent.AllowUserToAddRows = false;
            dataGridViewStudent.AllowUserToDeleteRows = false;
            dataGridViewStudent.AllowUserToResizeColumns = false;
            dataGridViewStudent.AllowUserToResizeRows = false;
            dataGridViewStudent.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            dataGridViewStudent.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewStudent.BackgroundColor = Color.White;
            dataGridViewStudent.BorderStyle = BorderStyle.None;
            dataGridViewStudent.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewStudent.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewStudent.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5 });
            dataGridViewStudent.Location = new Point(85, 185);
            dataGridViewStudent.Name = "dataGridViewStudent";
            dataGridViewStudent.ReadOnly = true;
            dataGridViewStudent.RowHeadersWidth = 51;
            dataGridViewStudent.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewStudent.ShowCellErrors = false;
            dataGridViewStudent.ShowEditingIcon = false;
            dataGridViewStudent.ShowRowErrors = false;
            dataGridViewStudent.Size = new Size(999, 436);
            dataGridViewStudent.TabIndex = 10;
            // 
            // Column1
            // 
            Column1.DataPropertyName = "Class_ID";
            Column1.HeaderText = "ID";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            // 
            // Column2
            // 
            Column2.DataPropertyName = "Class_Name";
            Column2.HeaderText = "Name";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            // 
            // Column3
            // 
            Column3.DataPropertyName = "Class_TotalStudents";
            Column3.HeaderText = "Reg No.";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            // 
            // Column4
            // 
            Column4.DataPropertyName = "Class_Male";
            Column4.HeaderText = "Class";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            Column4.ReadOnly = true;
            // 
            // Column5
            // 
            Column5.DataPropertyName = "Class_Female";
            Column5.HeaderText = "Gender";
            Column5.MinimumWidth = 6;
            Column5.Name = "Column5";
            Column5.ReadOnly = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = Properties.Resources.icons8_search_201;
            pictureBox1.Location = new Point(452, 126);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(19, 26);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // panel5
            // 
            panel5.BackColor = Color.LightGray;
            panel5.Location = new Point(201, 156);
            panel5.Name = "panel5";
            panel5.Size = new Size(270, 2);
            panel5.TabIndex = 8;
            // 
            // textBoxSearch
            // 
            textBoxSearch.BorderStyle = BorderStyle.None;
            textBoxSearch.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBoxSearch.Location = new Point(202, 129);
            textBoxSearch.Name = "textBoxSearch";
            textBoxSearch.Size = new Size(252, 21);
            textBoxSearch.TabIndex = 7;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(203, 99);
            label6.Name = "label6";
            label6.Size = new Size(87, 23);
            label6.TabIndex = 6;
            label6.Text = "Search:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.FromArgb(87, 143, 202);
            label7.Location = new Point(21, 20);
            label7.Name = "label7";
            label7.Size = new Size(197, 28);
            label7.TabIndex = 5;
            label7.Text = "Search Student:";
            // 
            // tabPageUpClass
            // 
            tabPageUpClass.Controls.Add(radioButtonMale2);
            tabPageUpClass.Controls.Add(radioButtonFemale2);
            tabPageUpClass.Controls.Add(comboBox2);
            tabPageUpClass.Controls.Add(panel6);
            tabPageUpClass.Controls.Add(labelGender1);
            tabPageUpClass.Controls.Add(textBox1);
            tabPageUpClass.Controls.Add(panel7);
            tabPageUpClass.Controls.Add(labelClass1);
            tabPageUpClass.Controls.Add(textBox2);
            tabPageUpClass.Controls.Add(panel8);
            tabPageUpClass.Controls.Add(labelRegNo1);
            tabPageUpClass.Controls.Add(textBox3);
            tabPageUpClass.Controls.Add(labelName1);
            tabPageUpClass.Controls.Add(buttonDelete);
            tabPageUpClass.Controls.Add(buttonUpdate);
            tabPageUpClass.Controls.Add(label14);
            tabPageUpClass.Location = new Point(4, 4);
            tabPageUpClass.Name = "tabPageUpClass";
            tabPageUpClass.Padding = new Padding(3);
            tabPageUpClass.Size = new Size(1157, 691);
            tabPageUpClass.TabIndex = 2;
            tabPageUpClass.Text = "Update and Delete Student";
            tabPageUpClass.UseVisualStyleBackColor = true;
            // 
            // radioButtonMale2
            // 
            radioButtonMale2.AutoSize = true;
            radioButtonMale2.Font = new Font("Century", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            radioButtonMale2.Location = new Point(785, 329);
            radioButtonMale2.Name = "radioButtonMale2";
            radioButtonMale2.Size = new Size(77, 26);
            radioButtonMale2.TabIndex = 42;
            radioButtonMale2.TabStop = true;
            radioButtonMale2.Text = "Male";
            radioButtonMale2.UseVisualStyleBackColor = true;
            // 
            // radioButtonFemale2
            // 
            radioButtonFemale2.AutoSize = true;
            radioButtonFemale2.Font = new Font("Century", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            radioButtonFemale2.Location = new Point(785, 382);
            radioButtonFemale2.Name = "radioButtonFemale2";
            radioButtonFemale2.Size = new Size(99, 26);
            radioButtonFemale2.TabIndex = 41;
            radioButtonFemale2.TabStop = true;
            radioButtonFemale2.Text = "Female";
            radioButtonFemale2.UseVisualStyleBackColor = true;
            // 
            // comboBox2
            // 
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.FlatStyle = FlatStyle.Flat;
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "-- SELECT --" });
            comboBox2.Location = new Point(131, 308);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(270, 26);
            comboBox2.TabIndex = 40;
            // 
            // panel6
            // 
            panel6.Anchor = AnchorStyles.None;
            panel6.BackColor = Color.LightGray;
            panel6.Location = new Point(131, 333);
            panel6.Name = "panel6";
            panel6.Size = new Size(270, 2);
            panel6.TabIndex = 0;
            // 
            // labelGender1
            // 
            labelGender1.Anchor = AnchorStyles.None;
            labelGender1.AutoSize = true;
            labelGender1.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelGender1.Location = new Point(687, 283);
            labelGender1.Name = "labelGender1";
            labelGender1.Size = new Size(91, 23);
            labelGender1.TabIndex = 0;
            labelGender1.Text = "Gender:";
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.None;
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(131, 309);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(270, 21);
            textBox1.TabIndex = 37;
            // 
            // panel7
            // 
            panel7.Anchor = AnchorStyles.None;
            panel7.BackColor = Color.LightGray;
            panel7.Location = new Point(691, 185);
            panel7.Name = "panel7";
            panel7.Size = new Size(270, 2);
            panel7.TabIndex = 0;
            // 
            // labelClass1
            // 
            labelClass1.Anchor = AnchorStyles.None;
            labelClass1.AutoSize = true;
            labelClass1.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelClass1.Location = new Point(126, 271);
            labelClass1.Name = "labelClass1";
            labelClass1.Size = new Size(71, 23);
            labelClass1.TabIndex = 0;
            labelClass1.Text = "Class:";
            // 
            // textBox2
            // 
            textBox2.Anchor = AnchorStyles.None;
            textBox2.BorderStyle = BorderStyle.None;
            textBox2.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(691, 161);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(270, 21);
            textBox2.TabIndex = 34;
            // 
            // panel8
            // 
            panel8.Anchor = AnchorStyles.None;
            panel8.BackColor = Color.LightGray;
            panel8.Location = new Point(131, 185);
            panel8.Name = "panel8";
            panel8.Size = new Size(270, 2);
            panel8.TabIndex = 0;
            // 
            // labelRegNo1
            // 
            labelRegNo1.Anchor = AnchorStyles.None;
            labelRegNo1.AutoSize = true;
            labelRegNo1.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelRegNo1.Location = new Point(687, 123);
            labelRegNo1.Name = "labelRegNo1";
            labelRegNo1.Size = new Size(90, 23);
            labelRegNo1.TabIndex = 0;
            labelRegNo1.Text = "Reg No:";
            // 
            // textBox3
            // 
            textBox3.Anchor = AnchorStyles.None;
            textBox3.BorderStyle = BorderStyle.None;
            textBox3.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox3.Location = new Point(131, 161);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(270, 21);
            textBox3.TabIndex = 31;
            // 
            // labelName1
            // 
            labelName1.Anchor = AnchorStyles.None;
            labelName1.AutoSize = true;
            labelName1.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelName1.Location = new Point(127, 123);
            labelName1.Name = "labelName1";
            labelName1.Size = new Size(76, 23);
            labelName1.TabIndex = 30;
            labelName1.Text = "Name:";
            // 
            // buttonDelete
            // 
            buttonDelete.Anchor = AnchorStyles.None;
            buttonDelete.BackColor = Color.FromArgb(253, 171, 158);
            buttonDelete.Cursor = Cursors.Hand;
            buttonDelete.FlatAppearance.BorderSize = 0;
            buttonDelete.FlatStyle = FlatStyle.Flat;
            buttonDelete.Font = new Font("Century", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonDelete.Location = new Point(325, 428);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(114, 37);
            buttonDelete.TabIndex = 29;
            buttonDelete.Text = "Delete";
            buttonDelete.UseVisualStyleBackColor = false;
            // 
            // buttonUpdate
            // 
            buttonUpdate.Anchor = AnchorStyles.None;
            buttonUpdate.BackColor = Color.FromArgb(128, 196, 233);
            buttonUpdate.Cursor = Cursors.Hand;
            buttonUpdate.FlatAppearance.BorderSize = 0;
            buttonUpdate.FlatStyle = FlatStyle.Flat;
            buttonUpdate.Font = new Font("Century", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonUpdate.Location = new Point(134, 428);
            buttonUpdate.Name = "buttonUpdate";
            buttonUpdate.Size = new Size(114, 37);
            buttonUpdate.TabIndex = 28;
            buttonUpdate.Text = "Update";
            buttonUpdate.UseVisualStyleBackColor = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Century", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.ForeColor = Color.FromArgb(87, 143, 202);
            label14.Location = new Point(26, 28);
            label14.Name = "label14";
            label14.Size = new Size(336, 28);
            label14.TabIndex = 15;
            label14.Text = "Update and Delete Student:";
            // 
            // Register
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1165, 722);
            Controls.Add(tabControl1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Register";
            Text = "Register";
            tabControl1.ResumeLayout(false);
            tabPageAddStudent.ResumeLayout(false);
            tabPageAddStudent.PerformLayout();
            tabPageSearchstudent.ResumeLayout(false);
            tabPageSearchstudent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewStudent).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tabPageUpClass.ResumeLayout(false);
            tabPageUpClass.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPageAddStudent;
        private RadioButton radioButtonMale1;
        private RadioButton radioButtonFemale1;
        private ComboBox comboBoxclass;
        private Button buttonAdd;
        private Panel panel3;
        private Label label5;
        private TextBox textBoxMale;
        private Panel panel2;
        private Label label4;
        private TextBox textBoxRegNo;
        private Panel panel1;
        private Label label3;
        private TextBox textBoxName;
        private Label label2;
        private Label label1;
        private TabPage tabPageSearchstudent;
        private ComboBox comboBox1;
        private Panel panel4;
        private Label label9;
        private Label labelCountStudent;
        private Label label8;
        private DataGridView dataGridViewStudent;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private PictureBox pictureBox1;
        private Panel panel5;
        private TextBox textBoxSearch;
        private Label label6;
        private Label label7;
        private TabPage tabPageUpClass;
        private RadioButton radioButtonMale2;
        private RadioButton radioButtonFemale2;
        private ComboBox comboBox2;
        private Panel panel6;
        private Label labelGender1;
        private TextBox textBox1;
        private Panel panel7;
        private Label labelClass1;
        private TextBox textBox2;
        private Panel panel8;
        private Label labelRegNo1;
        private TextBox textBox3;
        private Label labelName1;
        private Button buttonDelete;
        private Button buttonUpdate;
        private Label label14;
    }
}