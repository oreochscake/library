﻿namespace Attendance_System
{
    partial class AddClass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            toolTip = new ToolTip(components);
            tabControl1 = new TabControl();
            tabPageAddclass = new TabPage();
            buttonAdd = new Button();
            panel4 = new Panel();
            textBoxFemale = new TextBox();
            panel3 = new Panel();
            label5 = new Label();
            textBoxMale = new TextBox();
            panel2 = new Panel();
            label4 = new Label();
            textBox1 = new TextBox();
            panel1 = new Panel();
            label3 = new Label();
            textBoxName = new TextBox();
            label2 = new Label();
            label1 = new Label();
            tabPageSearchclass = new TabPage();
            labelCountClass = new Label();
            label8 = new Label();
            dataGridViewClass = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            pictureBox1 = new PictureBox();
            panel5 = new Panel();
            textBoxSearch = new TextBox();
            label6 = new Label();
            label7 = new Label();
            tabPageUpClass = new TabPage();
            buttonDelete = new Button();
            buttonUpdate = new Button();
            panel6 = new Panel();
            textBoxFemale1 = new TextBox();
            panel7 = new Panel();
            label10 = new Label();
            textBoxMale1 = new TextBox();
            panel8 = new Panel();
            label11 = new Label();
            textBoxHwStudents = new TextBox();
            panel9 = new Panel();
            label12 = new Label();
            textBoxName1 = new TextBox();
            label13 = new Label();
            label14 = new Label();
            tabControl1.SuspendLayout();
            tabPageAddclass.SuspendLayout();
            tabPageSearchclass.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewClass).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            tabPageUpClass.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Alignment = TabAlignment.Bottom;
            tabControl1.Controls.Add(tabPageAddclass);
            tabControl1.Controls.Add(tabPageSearchclass);
            tabControl1.Controls.Add(tabPageUpClass);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Font = new Font("Century", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1165, 722);
            tabControl1.TabIndex = 0;
            // 
            // tabPageAddclass
            // 
            tabPageAddclass.Controls.Add(buttonAdd);
            tabPageAddclass.Controls.Add(panel4);
            tabPageAddclass.Controls.Add(textBoxFemale);
            tabPageAddclass.Controls.Add(panel3);
            tabPageAddclass.Controls.Add(label5);
            tabPageAddclass.Controls.Add(textBoxMale);
            tabPageAddclass.Controls.Add(panel2);
            tabPageAddclass.Controls.Add(label4);
            tabPageAddclass.Controls.Add(textBox1);
            tabPageAddclass.Controls.Add(panel1);
            tabPageAddclass.Controls.Add(label3);
            tabPageAddclass.Controls.Add(textBoxName);
            tabPageAddclass.Controls.Add(label2);
            tabPageAddclass.Controls.Add(label1);
            tabPageAddclass.Location = new Point(4, 4);
            tabPageAddclass.Name = "tabPageAddclass";
            tabPageAddclass.Padding = new Padding(3);
            tabPageAddclass.Size = new Size(1157, 691);
            tabPageAddclass.TabIndex = 0;
            tabPageAddclass.Text = "Add Class";
            tabPageAddclass.UseVisualStyleBackColor = true;
            tabPageAddclass.Click += tabPage1_Click;
            // 
            // buttonAdd
            // 
            buttonAdd.Anchor = AnchorStyles.None;
            buttonAdd.BackColor = Color.FromArgb(128, 196, 233);
            buttonAdd.Cursor = Cursors.Hand;
            buttonAdd.FlatAppearance.BorderSize = 0;
            buttonAdd.FlatStyle = FlatStyle.Flat;
            buttonAdd.Font = new Font("Century", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonAdd.Location = new Point(121, 429);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(114, 37);
            buttonAdd.TabIndex = 14;
            buttonAdd.Text = "Add";
            buttonAdd.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            panel4.Anchor = AnchorStyles.None;
            panel4.BackColor = Color.LightGray;
            panel4.Location = new Point(681, 344);
            panel4.Name = "panel4";
            panel4.Size = new Size(270, 2);
            panel4.TabIndex = 13;
            // 
            // textBoxFemale
            // 
            textBoxFemale.Anchor = AnchorStyles.None;
            textBoxFemale.BorderStyle = BorderStyle.None;
            textBoxFemale.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBoxFemale.Location = new Point(681, 320);
            textBoxFemale.Name = "textBoxFemale";
            textBoxFemale.Size = new Size(270, 21);
            textBoxFemale.TabIndex = 12;
            // 
            // panel3
            // 
            panel3.Anchor = AnchorStyles.None;
            panel3.BackColor = Color.LightGray;
            panel3.Location = new Point(121, 332);
            panel3.Name = "panel3";
            panel3.Size = new Size(270, 2);
            panel3.TabIndex = 10;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(677, 282);
            label5.Name = "label5";
            label5.Size = new Size(91, 23);
            label5.TabIndex = 11;
            label5.Text = "Female:";
            // 
            // textBoxMale
            // 
            textBoxMale.Anchor = AnchorStyles.None;
            textBoxMale.BorderStyle = BorderStyle.None;
            textBoxMale.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBoxMale.Location = new Point(121, 308);
            textBoxMale.Name = "textBoxMale";
            textBoxMale.Size = new Size(270, 21);
            textBoxMale.TabIndex = 9;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.None;
            panel2.BackColor = Color.LightGray;
            panel2.Location = new Point(681, 184);
            panel2.Name = "panel2";
            panel2.Size = new Size(270, 2);
            panel2.TabIndex = 7;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(116, 270);
            label4.Name = "label4";
            label4.Size = new Size(67, 23);
            label4.TabIndex = 8;
            label4.Text = "Male:";
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.None;
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(681, 160);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(270, 21);
            textBox1.TabIndex = 6;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.None;
            panel1.BackColor = Color.LightGray;
            panel1.Location = new Point(121, 184);
            panel1.Name = "panel1";
            panel1.Size = new Size(270, 2);
            panel1.TabIndex = 4;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(677, 122);
            label3.Name = "label3";
            label3.Size = new Size(234, 23);
            label3.TabIndex = 5;
            label3.Text = "How many Students?:";
            // 
            // textBoxName
            // 
            textBoxName.Anchor = AnchorStyles.None;
            textBoxName.BorderStyle = BorderStyle.None;
            textBoxName.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBoxName.Location = new Point(121, 160);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(270, 21);
            textBoxName.TabIndex = 3;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(117, 122);
            label2.Name = "label2";
            label2.Size = new Size(76, 23);
            label2.TabIndex = 2;
            label2.Text = "Name:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(87, 143, 202);
            label1.Location = new Point(18, 17);
            label1.Name = "label1";
            label1.Size = new Size(136, 28);
            label1.TabIndex = 1;
            label1.Text = "Add Class:";
            // 
            // tabPageSearchclass
            // 
            tabPageSearchclass.Controls.Add(labelCountClass);
            tabPageSearchclass.Controls.Add(label8);
            tabPageSearchclass.Controls.Add(dataGridViewClass);
            tabPageSearchclass.Controls.Add(pictureBox1);
            tabPageSearchclass.Controls.Add(panel5);
            tabPageSearchclass.Controls.Add(textBoxSearch);
            tabPageSearchclass.Controls.Add(label6);
            tabPageSearchclass.Controls.Add(label7);
            tabPageSearchclass.Location = new Point(4, 4);
            tabPageSearchclass.Name = "tabPageSearchclass";
            tabPageSearchclass.Padding = new Padding(3);
            tabPageSearchclass.Size = new Size(1157, 691);
            tabPageSearchclass.TabIndex = 1;
            tabPageSearchclass.Text = "Search Class";
            tabPageSearchclass.UseVisualStyleBackColor = true;
            // 
            // labelCountClass
            // 
            labelCountClass.AutoSize = true;
            labelCountClass.Font = new Font("Century Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelCountClass.Location = new Point(947, 658);
            labelCountClass.Name = "labelCountClass";
            labelCountClass.Size = new Size(34, 23);
            labelCountClass.TabIndex = 12;
            labelCountClass.Text = "{?}";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(789, 658);
            label8.Name = "label8";
            label8.Size = new Size(152, 23);
            label8.TabIndex = 11;
            label8.Text = "Total Classes:";
            // 
            // dataGridViewClass
            // 
            dataGridViewClass.AllowUserToAddRows = false;
            dataGridViewClass.AllowUserToDeleteRows = false;
            dataGridViewClass.AllowUserToResizeColumns = false;
            dataGridViewClass.AllowUserToResizeRows = false;
            dataGridViewClass.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            dataGridViewClass.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewClass.BackgroundColor = Color.White;
            dataGridViewClass.BorderStyle = BorderStyle.None;
            dataGridViewClass.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewClass.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewClass.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5 });
            dataGridViewClass.Location = new Point(136, 199);
            dataGridViewClass.Name = "dataGridViewClass";
            dataGridViewClass.ReadOnly = true;
            dataGridViewClass.RowHeadersWidth = 51;
            dataGridViewClass.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewClass.ShowCellErrors = false;
            dataGridViewClass.ShowEditingIcon = false;
            dataGridViewClass.ShowRowErrors = false;
            dataGridViewClass.Size = new Size(872, 436);
            dataGridViewClass.TabIndex = 10;
            dataGridViewClass.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Column1
            // 
            Column1.DataPropertyName = "Class_ID";
            Column1.HeaderText = "ID";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            // 
            // Column2
            // 
            Column2.DataPropertyName = "Class_Name";
            Column2.HeaderText = "Name";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            // 
            // Column3
            // 
            Column3.DataPropertyName = "Class_TotalStudents";
            Column3.HeaderText = "How many Students?";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            // 
            // Column4
            // 
            Column4.DataPropertyName = "Class_Male";
            Column4.HeaderText = "Male";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            Column4.ReadOnly = true;
            // 
            // Column5
            // 
            Column5.DataPropertyName = "Class_Female";
            Column5.HeaderText = "Female";
            Column5.MinimumWidth = 6;
            Column5.Name = "Column5";
            Column5.ReadOnly = true;
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = Properties.Resources.icons8_search_20;
            pictureBox1.Location = new Point(452, 126);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(19, 26);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // panel5
            // 
            panel5.BackColor = Color.LightGray;
            panel5.Location = new Point(201, 156);
            panel5.Name = "panel5";
            panel5.Size = new Size(270, 2);
            panel5.TabIndex = 8;
            // 
            // textBoxSearch
            // 
            textBoxSearch.BorderStyle = BorderStyle.None;
            textBoxSearch.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBoxSearch.Location = new Point(202, 129);
            textBoxSearch.Name = "textBoxSearch";
            textBoxSearch.Size = new Size(252, 21);
            textBoxSearch.TabIndex = 7;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(197, 93);
            label6.Name = "label6";
            label6.Size = new Size(76, 23);
            label6.TabIndex = 6;
            label6.Text = "Name:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.FromArgb(87, 143, 202);
            label7.Location = new Point(18, 17);
            label7.Name = "label7";
            label7.Size = new Size(169, 28);
            label7.TabIndex = 5;
            label7.Text = "Search Class:";
            // 
            // tabPageUpClass
            // 
            tabPageUpClass.Controls.Add(buttonDelete);
            tabPageUpClass.Controls.Add(buttonUpdate);
            tabPageUpClass.Controls.Add(panel6);
            tabPageUpClass.Controls.Add(textBoxFemale1);
            tabPageUpClass.Controls.Add(panel7);
            tabPageUpClass.Controls.Add(label10);
            tabPageUpClass.Controls.Add(textBoxMale1);
            tabPageUpClass.Controls.Add(panel8);
            tabPageUpClass.Controls.Add(label11);
            tabPageUpClass.Controls.Add(textBoxHwStudents);
            tabPageUpClass.Controls.Add(panel9);
            tabPageUpClass.Controls.Add(label12);
            tabPageUpClass.Controls.Add(textBoxName1);
            tabPageUpClass.Controls.Add(label13);
            tabPageUpClass.Controls.Add(label14);
            tabPageUpClass.Location = new Point(4, 4);
            tabPageUpClass.Name = "tabPageUpClass";
            tabPageUpClass.Padding = new Padding(3);
            tabPageUpClass.Size = new Size(1157, 691);
            tabPageUpClass.TabIndex = 2;
            tabPageUpClass.Text = "Update and Delete Class";
            tabPageUpClass.UseVisualStyleBackColor = true;
            // 
            // buttonDelete
            // 
            buttonDelete.Anchor = AnchorStyles.None;
            buttonDelete.BackColor = Color.FromArgb(253, 171, 158);
            buttonDelete.Cursor = Cursors.Hand;
            buttonDelete.FlatAppearance.BorderSize = 0;
            buttonDelete.FlatStyle = FlatStyle.Flat;
            buttonDelete.Font = new Font("Century", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonDelete.Location = new Point(319, 432);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(114, 37);
            buttonDelete.TabIndex = 29;
            buttonDelete.Text = "Delete";
            buttonDelete.UseVisualStyleBackColor = false;
            // 
            // buttonUpdate
            // 
            buttonUpdate.Anchor = AnchorStyles.None;
            buttonUpdate.BackColor = Color.FromArgb(128, 196, 233);
            buttonUpdate.Cursor = Cursors.Hand;
            buttonUpdate.FlatAppearance.BorderSize = 0;
            buttonUpdate.FlatStyle = FlatStyle.Flat;
            buttonUpdate.Font = new Font("Century", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonUpdate.Location = new Point(128, 432);
            buttonUpdate.Name = "buttonUpdate";
            buttonUpdate.Size = new Size(114, 37);
            buttonUpdate.TabIndex = 28;
            buttonUpdate.Text = "Update";
            buttonUpdate.UseVisualStyleBackColor = false;
            // 
            // panel6
            // 
            panel6.Anchor = AnchorStyles.None;
            panel6.BackColor = Color.LightGray;
            panel6.Location = new Point(688, 347);
            panel6.Name = "panel6";
            panel6.Size = new Size(270, 2);
            panel6.TabIndex = 27;
            // 
            // textBoxFemale1
            // 
            textBoxFemale1.Anchor = AnchorStyles.None;
            textBoxFemale1.BorderStyle = BorderStyle.None;
            textBoxFemale1.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBoxFemale1.Location = new Point(688, 323);
            textBoxFemale1.Name = "textBoxFemale1";
            textBoxFemale1.Size = new Size(270, 21);
            textBoxFemale1.TabIndex = 26;
            // 
            // panel7
            // 
            panel7.Anchor = AnchorStyles.None;
            panel7.BackColor = Color.LightGray;
            panel7.Location = new Point(128, 335);
            panel7.Name = "panel7";
            panel7.Size = new Size(270, 2);
            panel7.TabIndex = 24;
            // 
            // label10
            // 
            label10.Anchor = AnchorStyles.None;
            label10.AutoSize = true;
            label10.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(684, 285);
            label10.Name = "label10";
            label10.Size = new Size(91, 23);
            label10.TabIndex = 25;
            label10.Text = "Female:";
            // 
            // textBoxMale1
            // 
            textBoxMale1.Anchor = AnchorStyles.None;
            textBoxMale1.BorderStyle = BorderStyle.None;
            textBoxMale1.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBoxMale1.Location = new Point(128, 311);
            textBoxMale1.Name = "textBoxMale1";
            textBoxMale1.Size = new Size(270, 21);
            textBoxMale1.TabIndex = 23;
            // 
            // panel8
            // 
            panel8.Anchor = AnchorStyles.None;
            panel8.BackColor = Color.LightGray;
            panel8.Location = new Point(688, 187);
            panel8.Name = "panel8";
            panel8.Size = new Size(270, 2);
            panel8.TabIndex = 21;
            // 
            // label11
            // 
            label11.Anchor = AnchorStyles.None;
            label11.AutoSize = true;
            label11.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.Location = new Point(123, 273);
            label11.Name = "label11";
            label11.Size = new Size(67, 23);
            label11.TabIndex = 22;
            label11.Text = "Male:";
            // 
            // textBoxHwStudents
            // 
            textBoxHwStudents.Anchor = AnchorStyles.None;
            textBoxHwStudents.BorderStyle = BorderStyle.None;
            textBoxHwStudents.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBoxHwStudents.Location = new Point(688, 163);
            textBoxHwStudents.Name = "textBoxHwStudents";
            textBoxHwStudents.Size = new Size(270, 21);
            textBoxHwStudents.TabIndex = 20;
            // 
            // panel9
            // 
            panel9.Anchor = AnchorStyles.None;
            panel9.BackColor = Color.LightGray;
            panel9.Location = new Point(128, 187);
            panel9.Name = "panel9";
            panel9.Size = new Size(270, 2);
            panel9.TabIndex = 18;
            // 
            // label12
            // 
            label12.Anchor = AnchorStyles.None;
            label12.AutoSize = true;
            label12.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(684, 125);
            label12.Name = "label12";
            label12.Size = new Size(234, 23);
            label12.TabIndex = 19;
            label12.Text = "How many Students?:";
            // 
            // textBoxName1
            // 
            textBoxName1.Anchor = AnchorStyles.None;
            textBoxName1.BorderStyle = BorderStyle.None;
            textBoxName1.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBoxName1.Location = new Point(128, 163);
            textBoxName1.Name = "textBoxName1";
            textBoxName1.Size = new Size(270, 21);
            textBoxName1.TabIndex = 17;
            // 
            // label13
            // 
            label13.Anchor = AnchorStyles.None;
            label13.AutoSize = true;
            label13.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(124, 125);
            label13.Name = "label13";
            label13.Size = new Size(76, 23);
            label13.TabIndex = 16;
            label13.Text = "Name:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Century", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.ForeColor = Color.FromArgb(87, 143, 202);
            label14.Location = new Point(25, 20);
            label14.Name = "label14";
            label14.Size = new Size(315, 28);
            label14.TabIndex = 15;
            label14.Text = "Update and Delete Class :";
            // 
            // AddClass
            // 
            AutoScaleDimensions = new SizeF(12F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1165, 722);
            Controls.Add(tabControl1);
            Font = new Font("Century", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "AddClass";
            Text = "AddClass";
            tabControl1.ResumeLayout(false);
            tabPageAddclass.ResumeLayout(false);
            tabPageAddclass.PerformLayout();
            tabPageSearchclass.ResumeLayout(false);
            tabPageSearchclass.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewClass).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            tabPageUpClass.ResumeLayout(false);
            tabPageUpClass.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private ToolTip toolTip;
        private TabControl tabControl1;
        private TabPage tabPageAddclass;
        private TabPage tabPageSearchclass;
        private Label label1;
        private Label label2;
        private TextBox textBoxName;
        private Panel panel1;
        private Panel panel2;
        private TextBox textBox1;
        private Label label3;
        private Panel panel3;
        private TextBox textBoxMale;
        private Label label4;
        private Panel panel4;
        private TextBox textBoxFemale;
        private Label label5;
        private Button buttonAdd;
        private Panel panel5;
        private TextBox textBoxSearch;
        private Label label6;
        private Label label7;
        private PictureBox pictureBox1;
        private DataGridView dataGridViewClass;
        private Label labelCountClass;
        private Label label8;
        private TabPage tabPageUpClass;
        private Button buttonUpdate;
        private Panel panel6;
        private TextBox textBoxFemale1;
        private Panel panel7;
        private Label label10;
        private TextBox textBoxMale1;
        private Panel panel8;
        private Label label11;
        private TextBox textBoxHwStudents;
        private Panel panel9;
        private Label label12;
        private TextBox textBoxName1;
        private Label label13;
        private Label label14;
        private Button buttonDelete;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
    }
}