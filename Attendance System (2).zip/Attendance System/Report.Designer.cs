﻿namespace Attendance_System
{
    partial class Report
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            tabControl1 = new TabControl();
            tabPageClassReport = new TabPage();
            dataGridViewMarkAttendance = new DataGridView();
            flowLayoutPanel7 = new FlowLayoutPanel();
            comboBoxClass1 = new ComboBox();
            label3 = new Label();
            flowLayoutPanel6 = new FlowLayoutPanel();
            flowLayoutPanel5 = new FlowLayoutPanel();
            flowLayoutPanel4 = new FlowLayoutPanel();
            flowLayoutPanel2 = new FlowLayoutPanel();
            flowLayoutPanel3 = new FlowLayoutPanel();
            flowLayoutPanel1 = new FlowLayoutPanel();
            label2 = new Label();
            label1 = new Label();
            dateTimePickerDate1 = new DateTimePicker();
            tabPageStudentReport = new TabPage();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            dataGridView1 = new DataGridView();
            dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn3 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
            flowLayoutPanel8 = new FlowLayoutPanel();
            comboBox2 = new ComboBox();
            label4 = new Label();
            flowLayoutPanel9 = new FlowLayoutPanel();
            flowLayoutPanel10 = new FlowLayoutPanel();
            flowLayoutPanel11 = new FlowLayoutPanel();
            flowLayoutPanel12 = new FlowLayoutPanel();
            flowLayoutPanel13 = new FlowLayoutPanel();
            flowLayoutPanel14 = new FlowLayoutPanel();
            label5 = new Label();
            label6 = new Label();
            dateTimePicker2 = new DateTimePicker();
            flowLayoutPanel16 = new FlowLayoutPanel();
            comboBox3 = new ComboBox();
            label8 = new Label();
            toolTip1 = new ToolTip(components);
            pictureBoxprint = new PictureBox();
            pictureBox1 = new PictureBox();
            tabControl1.SuspendLayout();
            tabPageClassReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewMarkAttendance).BeginInit();
            tabPageStudentReport.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxprint).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Alignment = TabAlignment.Bottom;
            tabControl1.Anchor = AnchorStyles.None;
            tabControl1.Controls.Add(tabPageClassReport);
            tabControl1.Controls.Add(tabPageStudentReport);
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(1165, 722);
            tabControl1.TabIndex = 1;
            // 
            // tabPageClassReport
            // 
            tabPageClassReport.BackColor = Color.White;
            tabPageClassReport.Controls.Add(pictureBoxprint);
            tabPageClassReport.Controls.Add(dataGridViewMarkAttendance);
            tabPageClassReport.Controls.Add(flowLayoutPanel7);
            tabPageClassReport.Controls.Add(comboBoxClass1);
            tabPageClassReport.Controls.Add(label3);
            tabPageClassReport.Controls.Add(flowLayoutPanel6);
            tabPageClassReport.Controls.Add(flowLayoutPanel5);
            tabPageClassReport.Controls.Add(flowLayoutPanel4);
            tabPageClassReport.Controls.Add(flowLayoutPanel2);
            tabPageClassReport.Controls.Add(flowLayoutPanel3);
            tabPageClassReport.Controls.Add(flowLayoutPanel1);
            tabPageClassReport.Controls.Add(label2);
            tabPageClassReport.Controls.Add(label1);
            tabPageClassReport.Controls.Add(dateTimePickerDate1);
            tabPageClassReport.Location = new Point(4, 4);
            tabPageClassReport.Name = "tabPageClassReport";
            tabPageClassReport.Padding = new Padding(3);
            tabPageClassReport.Size = new Size(1157, 689);
            tabPageClassReport.TabIndex = 0;
            tabPageClassReport.Text = "Class Report";
            tabPageClassReport.Click += tabPageClassReport_Click;
            // 
            // dataGridViewMarkAttendance
            // 
            dataGridViewMarkAttendance.AllowUserToAddRows = false;
            dataGridViewMarkAttendance.AllowUserToDeleteRows = false;
            dataGridViewMarkAttendance.AllowUserToResizeColumns = false;
            dataGridViewMarkAttendance.AllowUserToResizeRows = false;
            dataGridViewMarkAttendance.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            dataGridViewMarkAttendance.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewMarkAttendance.BackgroundColor = Color.White;
            dataGridViewMarkAttendance.BorderStyle = BorderStyle.None;
            dataGridViewMarkAttendance.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewMarkAttendance.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewMarkAttendance.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5 });
            dataGridViewMarkAttendance.Location = new Point(74, 204);
            dataGridViewMarkAttendance.Name = "dataGridViewMarkAttendance";
            dataGridViewMarkAttendance.ReadOnly = true;
            dataGridViewMarkAttendance.RowHeadersWidth = 51;
            dataGridViewMarkAttendance.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewMarkAttendance.ScrollBars = ScrollBars.Vertical;
            dataGridViewMarkAttendance.ShowCellErrors = false;
            dataGridViewMarkAttendance.ShowEditingIcon = false;
            dataGridViewMarkAttendance.ShowRowErrors = false;
            dataGridViewMarkAttendance.Size = new Size(998, 436);
            dataGridViewMarkAttendance.TabIndex = 11;
            // 
            // flowLayoutPanel7
            // 
            flowLayoutPanel7.Anchor = AnchorStyles.None;
            flowLayoutPanel7.BackColor = Color.Transparent;
            flowLayoutPanel7.Location = new Point(730, 144);
            flowLayoutPanel7.Name = "flowLayoutPanel7";
            flowLayoutPanel7.Size = new Size(270, 2);
            flowLayoutPanel7.TabIndex = 0;
            // 
            // comboBoxClass1
            // 
            comboBoxClass1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxClass1.FlatStyle = FlatStyle.Flat;
            comboBoxClass1.FormattingEnabled = true;
            comboBoxClass1.Location = new Point(730, 113);
            comboBoxClass1.Name = "comboBoxClass1";
            comboBoxClass1.Size = new Size(270, 28);
            comboBoxClass1.TabIndex = 0;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(719, 75);
            label3.Name = "label3";
            label3.Size = new Size(71, 23);
            label3.TabIndex = 9;
            label3.Text = "Class:";
            // 
            // flowLayoutPanel6
            // 
            flowLayoutPanel6.Anchor = AnchorStyles.None;
            flowLayoutPanel6.BackColor = Color.Transparent;
            flowLayoutPanel6.Location = new Point(387, 117);
            flowLayoutPanel6.Name = "flowLayoutPanel6";
            flowLayoutPanel6.Size = new Size(10, 24);
            flowLayoutPanel6.TabIndex = 0;
            // 
            // flowLayoutPanel5
            // 
            flowLayoutPanel5.Anchor = AnchorStyles.None;
            flowLayoutPanel5.BackColor = Color.Transparent;
            flowLayoutPanel5.Location = new Point(161, 144);
            flowLayoutPanel5.Name = "flowLayoutPanel5";
            flowLayoutPanel5.Size = new Size(270, 2);
            flowLayoutPanel5.TabIndex = 0;
            // 
            // flowLayoutPanel4
            // 
            flowLayoutPanel4.Anchor = AnchorStyles.None;
            flowLayoutPanel4.BackColor = Color.Transparent;
            flowLayoutPanel4.Location = new Point(430, 116);
            flowLayoutPanel4.Name = "flowLayoutPanel4";
            flowLayoutPanel4.Size = new Size(10, 24);
            flowLayoutPanel4.TabIndex = 0;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.Anchor = AnchorStyles.None;
            flowLayoutPanel2.BackColor = Color.Transparent;
            flowLayoutPanel2.Location = new Point(161, 140);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(270, 10);
            flowLayoutPanel2.TabIndex = 0;
            // 
            // flowLayoutPanel3
            // 
            flowLayoutPanel3.Anchor = AnchorStyles.None;
            flowLayoutPanel3.BackColor = Color.Transparent;
            flowLayoutPanel3.Location = new Point(152, 117);
            flowLayoutPanel3.Name = "flowLayoutPanel3";
            flowLayoutPanel3.Size = new Size(10, 24);
            flowLayoutPanel3.TabIndex = 0;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.Anchor = AnchorStyles.None;
            flowLayoutPanel1.BackColor = Color.Transparent;
            flowLayoutPanel1.Location = new Point(161, 107);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(270, 10);
            flowLayoutPanel1.TabIndex = 0;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Black;
            label2.Location = new Point(154, 75);
            label2.Name = "label2";
            label2.Size = new Size(66, 23);
            label2.TabIndex = 0;
            label2.Text = "Date:";
            label2.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(87, 143, 202);
            label1.Location = new Point(18, 17);
            label1.Name = "label1";
            label1.Size = new Size(169, 28);
            label1.TabIndex = 0;
            label1.Text = "Class Report:";
            // 
            // dateTimePickerDate1
            // 
            dateTimePickerDate1.CustomFormat = "yyyy/mm/dd";
            dateTimePickerDate1.Format = DateTimePickerFormat.Custom;
            dateTimePickerDate1.Location = new Point(162, 114);
            dateTimePickerDate1.Name = "dateTimePickerDate1";
            dateTimePickerDate1.Size = new Size(270, 27);
            dateTimePickerDate1.TabIndex = 0;
            // 
            // tabPageStudentReport
            // 
            tabPageStudentReport.Controls.Add(pictureBox1);
            tabPageStudentReport.Controls.Add(flowLayoutPanel16);
            tabPageStudentReport.Controls.Add(comboBox3);
            tabPageStudentReport.Controls.Add(label8);
            tabPageStudentReport.Controls.Add(dataGridView1);
            tabPageStudentReport.Controls.Add(flowLayoutPanel8);
            tabPageStudentReport.Controls.Add(comboBox2);
            tabPageStudentReport.Controls.Add(label4);
            tabPageStudentReport.Controls.Add(flowLayoutPanel9);
            tabPageStudentReport.Controls.Add(flowLayoutPanel10);
            tabPageStudentReport.Controls.Add(flowLayoutPanel11);
            tabPageStudentReport.Controls.Add(flowLayoutPanel12);
            tabPageStudentReport.Controls.Add(flowLayoutPanel13);
            tabPageStudentReport.Controls.Add(flowLayoutPanel14);
            tabPageStudentReport.Controls.Add(label5);
            tabPageStudentReport.Controls.Add(label6);
            tabPageStudentReport.Controls.Add(dateTimePicker2);
            tabPageStudentReport.Location = new Point(4, 4);
            tabPageStudentReport.Name = "tabPageStudentReport";
            tabPageStudentReport.Padding = new Padding(3);
            tabPageStudentReport.Size = new Size(1157, 689);
            tabPageStudentReport.TabIndex = 1;
            tabPageStudentReport.Text = "Student Report";
            tabPageStudentReport.UseVisualStyleBackColor = true;
            // 
            // Column1
            // 
            Column1.DataPropertyName = "Student_Name";
            Column1.HeaderText = "Student Name";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.ReadOnly = true;
            // 
            // Column2
            // 
            Column2.DataPropertyName = "Student_Reg";
            Column2.HeaderText = "Reg No.";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.ReadOnly = true;
            // 
            // Column3
            // 
            Column3.DataPropertyName = "Class_Name";
            Column3.HeaderText = "Class";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.ReadOnly = true;
            // 
            // Column4
            // 
            Column4.DataPropertyName = "Attendance_Date";
            Column4.HeaderText = "Date";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            Column4.ReadOnly = true;
            // 
            // Column5
            // 
            Column5.DataPropertyName = "Student_Status";
            Column5.HeaderText = "Status";
            Column5.MinimumWidth = 6;
            Column5.Name = "Column5";
            Column5.ReadOnly = true;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn2, dataGridViewTextBoxColumn3, dataGridViewTextBoxColumn4, dataGridViewTextBoxColumn5 });
            dataGridView1.Location = new Point(80, 209);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridView1.ScrollBars = ScrollBars.Vertical;
            dataGridView1.ShowCellErrors = false;
            dataGridView1.ShowEditingIcon = false;
            dataGridView1.ShowRowErrors = false;
            dataGridView1.Size = new Size(998, 436);
            dataGridView1.TabIndex = 24;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.DataPropertyName = "Student_Name";
            dataGridViewTextBoxColumn1.HeaderText = "Student Name";
            dataGridViewTextBoxColumn1.MinimumWidth = 6;
            dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewTextBoxColumn2.DataPropertyName = "Student_Reg";
            dataGridViewTextBoxColumn2.HeaderText = "Reg No.";
            dataGridViewTextBoxColumn2.MinimumWidth = 6;
            dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewTextBoxColumn3.DataPropertyName = "Class_Name";
            dataGridViewTextBoxColumn3.HeaderText = "Class";
            dataGridViewTextBoxColumn3.MinimumWidth = 6;
            dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewTextBoxColumn4.DataPropertyName = "Attendance_Date";
            dataGridViewTextBoxColumn4.HeaderText = "Date";
            dataGridViewTextBoxColumn4.MinimumWidth = 6;
            dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewTextBoxColumn5.DataPropertyName = "Student_Status";
            dataGridViewTextBoxColumn5.HeaderText = "Status";
            dataGridViewTextBoxColumn5.MinimumWidth = 6;
            dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // flowLayoutPanel8
            // 
            flowLayoutPanel8.Anchor = AnchorStyles.None;
            flowLayoutPanel8.BackColor = Color.Transparent;
            flowLayoutPanel8.Location = new Point(469, 154);
            flowLayoutPanel8.Name = "flowLayoutPanel8";
            flowLayoutPanel8.Size = new Size(270, 2);
            flowLayoutPanel8.TabIndex = 12;
            // 
            // comboBox2
            // 
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.FlatStyle = FlatStyle.Flat;
            comboBox2.FormattingEnabled = true;
            comboBox2.Location = new Point(469, 123);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(270, 28);
            comboBox2.TabIndex = 23;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Black;
            label4.Location = new Point(458, 85);
            label4.Name = "label4";
            label4.Size = new Size(71, 23);
            label4.TabIndex = 22;
            label4.Text = "Class:";
            // 
            // flowLayoutPanel9
            // 
            flowLayoutPanel9.Anchor = AnchorStyles.None;
            flowLayoutPanel9.BackColor = Color.Transparent;
            flowLayoutPanel9.Location = new Point(306, 127);
            flowLayoutPanel9.Name = "flowLayoutPanel9";
            flowLayoutPanel9.Size = new Size(10, 24);
            flowLayoutPanel9.TabIndex = 13;
            // 
            // flowLayoutPanel10
            // 
            flowLayoutPanel10.Anchor = AnchorStyles.None;
            flowLayoutPanel10.BackColor = Color.Transparent;
            flowLayoutPanel10.Location = new Point(80, 154);
            flowLayoutPanel10.Name = "flowLayoutPanel10";
            flowLayoutPanel10.Size = new Size(270, 2);
            flowLayoutPanel10.TabIndex = 14;
            // 
            // flowLayoutPanel11
            // 
            flowLayoutPanel11.Anchor = AnchorStyles.None;
            flowLayoutPanel11.BackColor = Color.Transparent;
            flowLayoutPanel11.Location = new Point(349, 126);
            flowLayoutPanel11.Name = "flowLayoutPanel11";
            flowLayoutPanel11.Size = new Size(10, 24);
            flowLayoutPanel11.TabIndex = 15;
            // 
            // flowLayoutPanel12
            // 
            flowLayoutPanel12.Anchor = AnchorStyles.None;
            flowLayoutPanel12.BackColor = Color.Transparent;
            flowLayoutPanel12.Location = new Point(80, 150);
            flowLayoutPanel12.Name = "flowLayoutPanel12";
            flowLayoutPanel12.Size = new Size(270, 10);
            flowLayoutPanel12.TabIndex = 16;
            // 
            // flowLayoutPanel13
            // 
            flowLayoutPanel13.Anchor = AnchorStyles.None;
            flowLayoutPanel13.BackColor = Color.Transparent;
            flowLayoutPanel13.Location = new Point(71, 127);
            flowLayoutPanel13.Name = "flowLayoutPanel13";
            flowLayoutPanel13.Size = new Size(10, 24);
            flowLayoutPanel13.TabIndex = 17;
            // 
            // flowLayoutPanel14
            // 
            flowLayoutPanel14.Anchor = AnchorStyles.None;
            flowLayoutPanel14.BackColor = Color.Transparent;
            flowLayoutPanel14.Location = new Point(80, 117);
            flowLayoutPanel14.Name = "flowLayoutPanel14";
            flowLayoutPanel14.Size = new Size(270, 10);
            flowLayoutPanel14.TabIndex = 18;
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Black;
            label5.Location = new Point(73, 85);
            label5.Name = "label5";
            label5.Size = new Size(66, 23);
            label5.TabIndex = 19;
            label5.Text = "Date:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.FromArgb(87, 143, 202);
            label6.Location = new Point(4, 3);
            label6.Name = "label6";
            label6.Size = new Size(197, 28);
            label6.TabIndex = 20;
            label6.Text = "Student Report:";
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.CustomFormat = "yyyy/mm/dd";
            dateTimePicker2.Format = DateTimePickerFormat.Custom;
            dateTimePicker2.Location = new Point(81, 124);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(270, 27);
            dateTimePicker2.TabIndex = 21;
            // 
            // flowLayoutPanel16
            // 
            flowLayoutPanel16.Anchor = AnchorStyles.None;
            flowLayoutPanel16.BackColor = Color.Transparent;
            flowLayoutPanel16.Location = new Point(851, 154);
            flowLayoutPanel16.Name = "flowLayoutPanel16";
            flowLayoutPanel16.Size = new Size(227, 2);
            flowLayoutPanel16.TabIndex = 25;
            // 
            // comboBox3
            // 
            comboBox3.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox3.FlatStyle = FlatStyle.Flat;
            comboBox3.FormattingEnabled = true;
            comboBox3.Location = new Point(851, 124);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(227, 28);
            comboBox3.TabIndex = 26;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.None;
            label8.AutoSize = true;
            label8.Font = new Font("Century", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.Black;
            label8.Location = new Point(842, 85);
            label8.Name = "label8";
            label8.Size = new Size(90, 23);
            label8.TabIndex = 27;
            label8.Text = "Reg No.";
            // 
            // pictureBoxprint
            // 
            pictureBoxprint.Image = Properties.Resources.icons8_print_301;
            pictureBoxprint.Location = new Point(1042, 6);
            pictureBoxprint.Name = "pictureBoxprint";
            pictureBoxprint.Size = new Size(30, 30);
            pictureBoxprint.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxprint.TabIndex = 12;
            pictureBoxprint.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.icons8_print_301;
            pictureBox1.Location = new Point(1048, 8);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(30, 30);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 28;
            pictureBox1.TabStop = false;
            // 
            // Report
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1165, 722);
            Controls.Add(tabControl1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Report";
            Text = "Report";
            tabControl1.ResumeLayout(false);
            tabPageClassReport.ResumeLayout(false);
            tabPageClassReport.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridViewMarkAttendance).EndInit();
            tabPageStudentReport.ResumeLayout(false);
            tabPageStudentReport.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxprint).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPageClassReport;
        private DataGridView dataGridViewMarkAttendance;
        private FlowLayoutPanel flowLayoutPanel7;
        private ComboBox comboBoxClass1;
        private Label label3;
        private FlowLayoutPanel flowLayoutPanel6;
        private FlowLayoutPanel flowLayoutPanel5;
        private FlowLayoutPanel flowLayoutPanel4;
        private FlowLayoutPanel flowLayoutPanel2;
        private FlowLayoutPanel flowLayoutPanel3;
        private FlowLayoutPanel flowLayoutPanel1;
        private Label label2;
        private Label label1;
        private DateTimePicker dateTimePickerDate1;
        private TabPage tabPageStudentReport;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private FlowLayoutPanel flowLayoutPanel8;
        private ComboBox comboBox2;
        private Label label4;
        private FlowLayoutPanel flowLayoutPanel9;
        private FlowLayoutPanel flowLayoutPanel10;
        private FlowLayoutPanel flowLayoutPanel11;
        private FlowLayoutPanel flowLayoutPanel12;
        private FlowLayoutPanel flowLayoutPanel13;
        private FlowLayoutPanel flowLayoutPanel14;
        private Label label5;
        private Label label6;
        private DateTimePicker dateTimePicker2;
        private FlowLayoutPanel flowLayoutPanel16;
        private ComboBox comboBox3;
        private Label label8;
        private PictureBox pictureBoxprint;
        private ToolTip toolTip1;
        private PictureBox pictureBox1;
    }
}